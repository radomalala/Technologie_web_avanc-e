const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Connexion MongoDB
mongoose.connect('mongodb://localhost:27017/etudiants', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.once('open', () => console.log('✅ Connecté à MongoDB'));

// Routes
const etudiantRoutes = require('./routes/etudiants');
app.use('/api/etudiants', etudiantRoutes);

app.listen(3000, () => console.log('🚀 Serveur lancé sur http://localhost:3000'));
