const express = require('express');
const router = express.Router();
const Etudiant = require('../models/Etudiant');

router.post('/', async (req, res) => {
  const etu = new Etudiant(req.body);
  const saved = await etu.save();
  res.json(saved);
});

router.get('/', async (req, res) => {
  const etudiants = await Etudiant.find();
  res.json(etudiants);
});

router.get('/:id', async (req, res) => {
  const etu = await Etudiant.findById(req.params.id);
  res.json(etu);
});

router.put('/:id', async (req, res) => {
  const updated = await Etudiant.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

router.delete('/:id', async (req, res) => {
  await Etudiant.findByIdAndDelete(req.params.id);
  res.json({ message: 'Étudiant supprimé' });
});

module.exports = router;
