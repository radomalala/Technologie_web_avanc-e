import { useEffect, useState } from 'react';

function App() {
  const [etudiants, setEtudiants] = useState([]);
  const [form, setForm] = useState({ nom: '', age: '', email: '' });

  useEffect(() => {
    fetch('http://localhost:3000/api/etudiants')
      .then(res => res.json())
      .then(setEtudiants);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:3000/api/etudiants', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
      .then(res => res.json())
      .then(data => {
        setEtudiants([...etudiants, data]);
        setForm({ nom: '', age: '', email: '' });
      });
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Liste des étudiants</h1>
      <form onSubmit={handleSubmit}>
        <input placeholder="Nom" value={form.nom} onChange={e => setForm({ ...form, nom: e.target.value })} />
        <input placeholder="Age" type="number" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} />
        <input placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        <button type="submit">Ajouter</button>
      </form>
      <ul>
        {etudiants.map((e, i) => (
          <li key={i}>{e.nom} - {e.age} ans - {e.email}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
