# Projet Final – Template Fullstack (React + Express + MongoDB)

Ce template fournit une base **prête à l’emploi** :
- Frontend : React + Vite
- Backend : Node.js + Express (+ MongoDB en option)
- Communication : CORS activé, API sur `/api/*`

## Démarrage
### Backend
```bash
cd server
npm install
cp .env.example .env
npm run dev
```

### Frontend
```bash
cd client
npm install
npm run dev
```

Par défaut : 
- API : http://localhost:3000/api
- Front : http://localhost:5173
