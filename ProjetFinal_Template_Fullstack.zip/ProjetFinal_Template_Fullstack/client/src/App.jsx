import React, { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:3000/api'

export default function App(){
  const [contacts, setContacts] = useState([])
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')

  const load = async () => {
    const res = await fetch(`${API}/contacts`)
    setContacts(await res.json())
  }

  const add = async (e) => {
    e.preventDefault()
    const res = await fetch(`${API}/contacts`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name, email })
    })
    if(res.ok){
      setName(''); setEmail(''); load()
    }
  }

  useEffect(()=>{ load() }, [])

  return (
    <div style={{maxWidth: 600, margin:'40px auto', fontFamily:'sans-serif'}}>
      <h1>Contacts</h1>

      <form onSubmit={add} style={{display:'flex', gap:8, marginBottom:16}}>
        <input placeholder="Nom" value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <button>Ajouter</button>
      </form>

      <ul>
        {contacts.map(c => <li key={c.id}>{c.name} – {c.email}</li>)}
      </ul>
      <p style={{marginTop:24, color:'#666'}}>API: {API}</p>
    </div>
  )
}
