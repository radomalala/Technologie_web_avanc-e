import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import morgan from 'morgan';

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// In-memory store (remplacer par MongoDB si besoin)
let contacts = [
  { id: 1, name: "Alice", email: "alice@test.com" },
  { id: 2, name: "Bob", email: "bob@test.com" }
];

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.get('/api/contacts', (_req, res) => res.json(contacts));

app.post('/api/contacts', (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'name & email required' });
  const c = { id: Date.now(), name, email };
  contacts.push(c);
  res.status(201).json(c);
});

app.put('/api/contacts/:id', (req, res) => {
  const id = Number(req.params.id);
  const i = contacts.findIndex(c => c.id === id);
  if (i < 0) return res.status(404).end();
  contacts[i] = { ...contacts[i], ...req.body };
  res.json(contacts[i]);
});

app.delete('/api/contacts/:id', (req, res) => {
  const id = Number(req.params.id);
  contacts = contacts.filter(c => c.id !== id);
  res.status(204).end();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
