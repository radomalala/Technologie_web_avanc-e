npm install
npm audit fix --force
npm run dev
** Changer de port : npm run dev -- --port=3000